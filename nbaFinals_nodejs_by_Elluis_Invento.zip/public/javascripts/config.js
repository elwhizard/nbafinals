var config = {
    host: '/'
}
