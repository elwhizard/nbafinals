define([
    'backgrid',
    '/js/collections/Games.js'
], function(Backgrid, GameCol){

    console.log('main view')
//    var columns = [{
//        name: "name",
//        label: "Name",
//        // The cell type can be a reference of a Backgrid.Cell subclass, any Backgrid.Cell subclass instances like *id* above, or a string
//        cell: "string" // This is converted to "StringCell" and a corresponding class in the Backgrid package namespace is looked up
//    }, {
//        name: "pop",
//        label: "Population",
//        cell: "integer" // An integer cell is a number cell that displays humanized integers
//    }, {
//        name: "percentage",
//        label: "% of World Population",
//        cell: "number" // A cell type for floating point value, defaults to have a precision 2 decimal numbers
//    }, {
//        name: "date",
//        label: "Date",
//        cell: "date",
//    }, {
//        name: "url",
//        label: "URL",
//        cell: "uri" // Renders the value in an HTML anchor element
//    }];
//
//// Initialize a new Grid instance
//    var grid = new Backgrid.Grid({
//        columns: columns,
//        collection: GameCol
//    });
//
//    $('#currentGame').append(grid.render().$el);
//
    return;

});
