Ext.data.JsonP.Backgrid_Columns({
  "tagname": "class",
  "name": "Backgrid.Columns",
  "extends": "Backbone.Collection",
  "mixins": [

  ],
  "alternateClassNames": [

  ],
  "aliases": {
  },
  "singleton": false,
  "requires": [

  ],
  "uses": [

  ],
  "enum": null,
  "override": null,
  "inheritable": null,
  "inheritdoc": null,
  "meta": {
  },
  "private": null,
  "id": "class-Backgrid.Columns",
  "members": {
    "cfg": [

    ],
    "property": [
      {
        "name": "model",
        "tagname": "property",
        "owner": "Backgrid.Columns",
        "meta": {
        },
        "id": "property-model"
      }
    ],
    "method": [

    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ]
  },
  "linenr": 73,
  "files": [
    {
      "filename": "column.js",
      "href": null
    }
  ],
  "html_meta": {
  },
  "statics": {
    "cfg": [

    ],
    "property": [

    ],
    "method": [

    ],
    "event": [

    ],
    "css_var": [

    ],
    "css_mixin": [

    ]
  },
  "component": false,
  "superclasses": [
    "Backbone.Collection"
  ],
  "subclasses": [

  ],
  "mixedInto": [

  ],
  "parentMixins": [

  ],
  "html": "<div><pre class=\"hierarchy\"><h4>Hierarchy</h4><div class='subclass first-child'>Backbone.Collection<div class='subclass '><strong>Backgrid.Columns</strong></div></div></pre><div class='doc-contents'><p>A Backbone collection of Column instances.</p>\n</div><div class='members'><div class='members-section'><div class='definedBy'>Defined By</div><h3 class='members-title icon-property'>Properties</h3><div class='subsection'><div id='property-model' class='member first-child not-inherited'><a href='#' class='side expandable'><span>&nbsp;</span></a><div class='title'><div class='meta'><span class='defined-in' rel='Backgrid.Columns'>Backgrid.Columns</span><br/></div><a href='#!/api/Backgrid.Columns-property-model' class='name not-expandable'>model</a><span> : <a href=\"#!/api/Backgrid.Column\" rel=\"Backgrid.Column\" class=\"docClass\">Backgrid.Column</a></span></div><div class='description'><div class='short'>\n</div><div class='long'>\n</div></div></div></div></div></div></div>"
});